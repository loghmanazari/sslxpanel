<?php
//ini_set('display_errors', '1');
//ini_set('display_startup_errors', '1');
//error_reporting(E_ALL);
require_once("../app/Config/database.php");
require_once("../app/Config/define.php");
require_once("../app/Libs/Controller.php");
require_once("../app/Libs/View.php");

require_once("../app/Libs/Model.php");
require_once("../app/Libs/Database.php");

require_once("../app/Libs/Session.php");
require_once("../app/Libs/Bootstrap.php");

$app = new Bootstrap();
?>
